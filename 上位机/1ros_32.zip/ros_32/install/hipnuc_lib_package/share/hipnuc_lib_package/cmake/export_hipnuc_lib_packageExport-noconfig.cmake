#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hipnuc_lib_package::hipnuc_lib_package" for configuration ""
set_property(TARGET hipnuc_lib_package::hipnuc_lib_package APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(hipnuc_lib_package::hipnuc_lib_package PROPERTIES
  IMPORTED_LOCATION_NOCONFIG "${_IMPORT_PREFIX}/lib/libhipnuc_lib_package.so"
  IMPORTED_SONAME_NOCONFIG "libhipnuc_lib_package.so"
  )

list(APPEND _IMPORT_CHECK_TARGETS hipnuc_lib_package::hipnuc_lib_package )
list(APPEND _IMPORT_CHECK_FILES_FOR_hipnuc_lib_package::hipnuc_lib_package "${_IMPORT_PREFIX}/lib/libhipnuc_lib_package.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
